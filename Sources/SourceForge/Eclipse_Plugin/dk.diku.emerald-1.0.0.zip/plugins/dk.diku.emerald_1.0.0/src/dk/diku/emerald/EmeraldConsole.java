/*
 * The Emerald Language Eclipse Plugin
 * 
 * Copyright (C) 2004 Mathias Bertelsen <mathias@bertelsen.co.uk>
 * 
 * This file is part of the Emerald Language Eclipse Plugin.
 *
 * The Emerald Language Eclipse Plugin is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 *  The Emerald Language Eclipse Plugin is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with the Emerald Language Eclipse Plugin; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Created on Nov 22, 2004
 *
 */

package dk.diku.emerald;
    import org.eclipse.jface.text.Document;
    import org.eclipse.jface.text.TextViewer;
    import org.eclipse.swt.SWT;
    import org.eclipse.swt.layout.GridData;
    import org.eclipse.swt.widgets.Composite;
    import org.eclipse.ui.internal.console.ConsoleView;
    import org.eclipse.ui.part.ViewPart;

/**
 * @author mb
 *
 */
public class EmeraldConsole  extends ConsoleView {

    	public static final String CONSOLE_ID = "dk.diku.emerald.EmeraldConsole";
    	
    	private TextViewer viewer = null;
    	private Document document = null;

    	/**
    	 * The constructor.
    	 */
        public EmeraldConsole() {
            
        }

        //
        
    	/**
    	 * @see ViewPart#createPartControl
    	 */
    	public void createPartControl(Composite parent)  {
    		viewer = new TextViewer(parent, SWT.WRAP | SWT.V_SCROLL | SWT.H_SCROLL);
    		GridData viewerData = new GridData(GridData.FILL_BOTH);
    		viewer.getControl().setLayoutData(viewerData);
    		viewer.setEditable(true);
    	}

    	/**
    	 * @see ViewPart#setFocus
    	 */
    	public void setFocus()  {
    	}
    	
    	/**
    	 * Set the text for the viewer
    	 */
    	public void setOutputText(String text) {
    		document = new Document(text);
    		viewer.setDocument(document);
    	}
    }



